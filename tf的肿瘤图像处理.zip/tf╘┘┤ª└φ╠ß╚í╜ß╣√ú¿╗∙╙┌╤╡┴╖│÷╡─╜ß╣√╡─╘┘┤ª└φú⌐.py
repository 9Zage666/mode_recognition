import tensorflow as tf
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import numpy as np
import pandas as pd
import csv
import cv2
from PIL import Image as img

myimg1 = mpimg.imread('0t.png')
plt.imshow(myimg1)
plt.axis('off')
print(myimg1.shape)

full1 = np.reshape(myimg1,[1,512,512,4])
inputfull = tf.Variable(tf.constant(1.0,shape = [1,512,512,4]))
filter = tf.Variable(tf.constant([[-1.0,-1.0,-1.0,-1.0],[0,0,0,0],[1.0,1.0,1.0,1.0],[-2.0,-2.0,-2.0,-2.0],[0,0,0,0],[2.0,2.0,2.0,2.0],[-1.0,-1.0,-1.0,-1.0],[0,0,0,0],[1.0,1.0,1.0,1.0]],shape = [3,3,4,1]))
op = tf.nn.conv2d(inputfull,filter,strides = [1,1,1,1],padding='VALID')
o = tf.cast(((op - tf.reduce_min(op))/tf.reduce_max(op)-tf.reduce_min(op))*255,tf.uint8)

with tf.Session() as sess:
    sess.run(tf.global_variables_initializer())
    t,f = sess.run([o,filter],feed_dict = {inputfull:full1})
    t = np.reshape(t,[510,510])
    plt.imshow(t)
    plt.show()
    t = np.reshape(t,[510,510])
    print(t.shape)
    plt.imshow(t,cmap='Greys_r')
    plt.show()
    gray = cv2.cvtColor(t,cv2.COLOR_RGB2GRAY)
    blurred = cv2.GaussianBlur(gray, (3, 3), 0)

    gradX = cv2.Sobel(gray, ddepth=cv2.CV_32F, dx=1, dy=0)
    gradY = cv2.Sobel(gray, ddepth=cv2.CV_32F, dx=0, dy=1)

    gradient = cv2.subtract(gradX, gradY)
    gradient = cv2.convertScaleAbs(gradient)
    blurred1 = cv2.GaussianBlur(gradient, (9, 9), 0)
    (_, thresh) = cv2.threshold(blurred1, 90, 255, cv2.THRESH_BINARY)
    kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (25, 25))
    closed = cv2.morphologyEx(thresh, cv2.MORPH_CLOSE, kernel)
    #closed = cv2.erode(closed, None, iterations=2)
    #closed = cv2.dilate(closed, None, iterations=2)
    fig1 = plt.gcf()
    plt.imshow(closed)
    plt.show()
    fig1.savefig('test.png', dpi=100)


