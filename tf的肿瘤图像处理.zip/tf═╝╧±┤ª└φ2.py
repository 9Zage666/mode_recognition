import numpy as np
import matplotlib.pyplot as plt
import skimage.data as data
import skimage.segmentation as seg
import skimage.filters as filters
import skimage.draw as draw
import skimage.color as color

from skimage import io

def image_show(image, nrows=1, ncols=1, cmap='gray'):
    fig, ax = plt.subplots(nrows=nrows, ncols=ncols, figsize=(14, 14))
    ax.imshow(image, cmap='gray')
    ax.axis('off')
    return fig, ax

def circle_points(resolution, center, radius):
    """
     Generate points which define a circle on an image.Centre refers to the centre of the circle
     """
    radians = np.linspace(0, 2 * np.pi, resolution)
    c = center[1] + radius * np.cos(radians)  # polar co-ordinates
    r = center[0] + radius * np.sin(radians)
    return np.array([c, r]).T
points = circle_points(200, [100, 350], 60)[:-1];
image = io.imread('5c6a88528bfa9.png')
plt.imshow(image)
image_gray = color.rgb2gray(image)
plt.imshow(image_gray)
image_show(image_gray)

indices = draw.circle_perimeter(80, 250,20)#from here
image_labels = np.zeros(image_gray.shape, dtype=np.uint8)
image_labels[indices] = 1
image_labels[points[:, 1].astype(np.int), points[:, 0].astype(np.int)] = 2
image_show(image_labels)
image_segmented = seg.random_walker(image_gray, image_labels)
# Check our results
fig, ax = image_show(image_gray)
ax.imshow(image_segmented == 1, alpha=0.3)
